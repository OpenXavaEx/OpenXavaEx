package org.directwebremoting.webwork;

/**
 * Marker interface for wrapped invocation results.
 *
 * @author <a href='mailto:the_mindstorm[at]evolva[dot]ro'>Alexandru Popescu</a>
 */
public interface AjaxResult
{
}
